package integration;

public class DocumentProcessingIntegrationTest {
}
