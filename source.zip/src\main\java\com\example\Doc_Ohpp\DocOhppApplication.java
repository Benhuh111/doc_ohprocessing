package com.example.Doc_Ohpp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocOhppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocOhppApplication.class, args);
	}

}